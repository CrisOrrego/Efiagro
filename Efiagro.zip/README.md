## Efiagro

Repositorio GIT del proyecto Efiagro, "Gestión Empresarial para el Desarrollo Rural".
<!doctype html>
<html lang="es" ng-app="App" ngs-strict-di>

	<head>
		<meta charset="UTF-8">
		<title><?php echo e(env('APP_NAME')); ?></title>
		<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimal-ui">
		<meta name="apple-mobile-web-app-capable" content="yes">
		<meta name="mobile-web-app-capable" content="yes">

		<link   rel="stylesheet"              		href="/css/libs.min.css?202010051927" />
		<link   rel="stylesheet"              		href="/css/app.min.css?202010051927" />
		

		<script type="application/javascript" src="/js/libs.min.js"></script>
		<script defer type="application/javascript" src="/js/app.min.js?202010051927"></script>
		<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCjjB89k3h2YU7w4NTNQ6euTDtuQ8IeH7g">
		</script>
	
	</head>

	<body layout ui-view></body>
	
</html><?php /**PATH C:\Users\MAHS\Documents\GitHub\Efiagro\resources\views/Base.blade.php ENDPATH**/ ?>
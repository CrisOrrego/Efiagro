<div id="MiTecnicoAmigo" flex layout=column ng-controller="MiTecnicoAmigoCtrl">

	@include('MiTecnicoAmigo.MiTecnicoAmigo_Articulos')
	@include('MiTecnicoAmigo.MiTecnicoAmigo_Solicitudes')

</div>

<style type="text/css">
	
	.boton-principal{
		border-radius: 100px;
		padding: 6px 30px;
		font-size: 1.1em;
		text-shadow: 1px 1px 1px #00000066;
	}

</style>
<div ng-show="!CredSel">

	<md-card ng-repeat="CredSel in Creditos" class="Cred relative Pointer" md-ink-ripple="#000000" 
		ng-click="ViewCredit(CredSel)">
		<?php echo $__env->make('FondoRotatorio.Creditos_CreditCard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	</md-card>

	<md-button ng-click="nuevoCredito($event)"
		class="md-fab md-fab-bottom-right pos-fixed no-margin" aria-label="Nuevo Credito">
		<md-tooltip md-direction=left>Nuevo Crédito</md-tooltip>
		<md-icon md-svg-icon="md-plus"></md-icon>
	</md-button>

</div><?php /**PATH C:\Users\MAHS\Documents\GitHub\Efiagro\resources\views/FondoRotatorio/Creditos_CreditosLista.blade.php ENDPATH**/ ?>
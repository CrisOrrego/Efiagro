<div id="FondoRotatorio_MisCreditos" flex layout=column layout-align="start center" ng-controller="FondoRotatorio_MisCreditosCtrl">
	
	<md-card ng-repeat="CredSel in CreditosCRUD.rows" 
		class="Cred relative Pointer mxw850" md-ink-ripple="#000000" 
		ng-click="printCredit(CredSel)">
		<?php echo $__env->make('FondoRotatorio.Creditos_CreditCard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	</md-card>

</div><?php /**PATH C:\Users\MAHS\Documents\GitHub\Efiagro\resources\views/FondoRotatorio/MisCreditos.blade.php ENDPATH**/ ?>
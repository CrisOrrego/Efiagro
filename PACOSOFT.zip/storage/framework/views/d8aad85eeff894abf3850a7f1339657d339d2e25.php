<div ng-cloak id="MiOrganizacion" ng-controller="FincasCtrl" class="divMiOrganizacion w650">
    

<md-tab label="Mi Organización" ng-click="">
    <md-content class="md-padding">

        <p>Integer turpis erat, porttitor vitae mi faucibus, laoreet interdum tellus. Curabitur
            posuere molestie dictum. Morbi eget congue risus, quis rhoncus quam. Suspendisse vitae
            hendrerit erat, at posuere mi. Cras eu fermentum nunc. Sed id ante eu orci commodo
            volutpat non ac est. Praesent ligula diam, congue eu enim scelerisque, finibus commodo
            lectus.</p>
    </md-content>
</md-tab>

</div>

<style type="text/css">
  
    md-tabs {
        /* background-image: url("/../imgs/finca.jpg"); */
        background-repeat: no-repeat;
        background-size: cover;

    }

</style>
<?php /**PATH C:\Users\MAHS\Documents\GitHub\Efiagro\resources\views/MiFinca/Organizacion.blade.php ENDPATH**/ ?>
angular.module('BottomSheetCtrl', [])
.controller('BottomSheetCtrl', ['$scope', '$rootScope', '$mdBottomSheet', 'Config', 
	function($scope, $rootScope, $mdBottomSheet, Config) {

		var Ctrl = $scope;
		var Rs = $rootScope;
	
		Ctrl.Cancel = function(){ $mdBottomSheet.cancel(); }

		Ctrl.Config = angular.copy(Config);

		Ctrl.Send = function(Item){
			$mdBottomSheet.hide(Item);
		}
	}
]);
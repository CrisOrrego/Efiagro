angular.module('MainCtrl', [])
.controller('MainCtrl', ['$rootScope', 
	function($rootScope){
		let Rs = $rootScope;
	}
]);
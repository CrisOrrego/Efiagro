<md-input-container class="margin-bottom-5">
	<input type="text" ng-model="Asociado.nombre" placeholder="Nombre" readonly>
</md-input-container>

<md-input-container class="margin-bottom-5">
	<input type="text" ng-model="Asociado.documento" placeholder="Cedula" readonly>
</md-input-container>

<md-input-container class="margin-bottom-5">
	<input type="text" ng-model="Asociado.correo" placeholder="Correo" readonly>
</md-input-container>
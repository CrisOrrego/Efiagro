<div ng-cloak id="Eventos" ng-controller="EventosCtrl" class="divEventos w650">
    {{-- SECCIÓN EVENTOS --}}
        <md-content class="md-padding">
            <md-card class="seccion_eventos">
                <div>
                    <h3 class="md-title no-margin">Eventos</h3>
                </div>
                <p>Integer turpis erat, porttitor vitae mi faucibus, laoreet interdum tellus. Curabitur
                    posuere molestie dictum. Morbi eget congue risus, quis rhoncus quam. Suspendisse vitae
                    hendrerit erat, at posuere mi. Cras eu fermentum nunc. Sed id ante eu orci commodo
                    volutpat non ac est. Praesent ligula diam, congue eu enim scelerisque, finibus commodo
                    lectus.</p>
            </md-card>

        </md-content>
    </md-tab>
</div>

<style type="text/css">
   
    .encabezado {
        border-radius: 1rem;
    }

</style>

<div id="MiTecnicoAmigo" flex layout=column ng-controller="MiTecnicoAmigoCtrl">

	<?php echo $__env->make('MiTecnicoAmigo.MiTecnicoAmigo_Articulos', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<?php echo $__env->make('MiTecnicoAmigo.MiTecnicoAmigo_Solicitudes', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</div>

<style type="text/css">
	
	.boton-principal{
		border-radius: 100px;
		padding: 6px 30px;
		font-size: 1.1em;
		text-shadow: 1px 1px 1px #00000066;
	}

</style><?php /**PATH C:\Users\MAHS\Documents\GitHub\Efiagro\resources\views/MiTecnicoAmigo/MiTecnicoAmigo.blade.php ENDPATH**/ ?>
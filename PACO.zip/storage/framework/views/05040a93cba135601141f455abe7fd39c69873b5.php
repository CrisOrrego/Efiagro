<div id="CreditDetail" flex layout="column" ng-hide="CredSel == null" class="overflow-y">

	<md-card id="CredSelDetails" class="Cred">
		<?php echo $__env->make('FondoRotatorio.Creditos_CreditCard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	</md-card>

	<md-card flex class="no-margin-top">
		<md-tabs md-border-bottom flex class="md-tabs-fullheight">

			<md-tab label="Cuotas">
				<md-content layout="column">
					<div layout=column flex>
						<?php echo $__env->make('FondoRotatorio.Creditos_CreditList_Cuotas', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
					</div>

					<div layout ng-show="CredSel.estado !== 'Terminado' ">
						<span flex></span>
						<md-button aria-label="Pagar" class="md-raised md-primary bg-primary"
							ng-click="NewAbono($event)">
							<md-icon md-font-icon="fa-plus" class="margin-right-5"></md-icon>
							Agregar Pago
						</md-button>
					</div>

				</md-content>
			</md-tab>

			<md-tab label="Pagos">
				<md-content layout="column" class="well"  layout-align="start center">
					<?php echo $__env->make('FondoRotatorio.Creditos_CreditList_Pagos', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
					<div class="mh50"></div>
				</md-content>
			</md-tab>

			<!--<md-tab label="Bitácora">
				<md-content layout class="well padding-left padding-right"  layout-align="center start">
					include('FondoRotatorio.Creditos_Comments')
				</md-content>
			</md-tab>-->

		</md-tabs>
	</md-card>

</div><?php /**PATH C:\Users\MAHS\Documents\GitHub\Efiagro\resources\views/FondoRotatorio/Creditos_CreditDetail.blade.php ENDPATH**/ ?>
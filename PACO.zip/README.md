## PACO

Repositorio GIT del proyecto PACO, "Gestión Empresarial para el Desarrollo Rural".